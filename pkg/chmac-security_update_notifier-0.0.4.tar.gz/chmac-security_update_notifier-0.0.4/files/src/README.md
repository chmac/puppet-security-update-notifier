security-update-notifier
========================

Simple shell script to notify by email when security updates are outstanding

Requirements
-----

This script relies on at least the update-notifier-common package on Ubuntu. If you find other requirements please submit an issue or pull request.

Install
-----

Copy the file security-udpate-notifier.sh to your local filesystem and add it to cron.

Improvements
----

This script is ten line simple. It could be dramatically improved. See the tickets for ideas, pull requests welcome.