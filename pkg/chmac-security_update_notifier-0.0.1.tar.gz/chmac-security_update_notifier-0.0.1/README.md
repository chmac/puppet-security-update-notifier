puppet-security-update-notifier
===============================

Simple puppet module to install security-update-notifier
